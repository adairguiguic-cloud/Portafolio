# Lab 06 Adair Alejandro Guigui Cardona
awa de uwu
