﻿using System;
class Program
{
    static void Main()
    {
        Console.Clear();

        E1();
        Console.WriteLine("\n---------------------------\n");

        E2();
        Console.WriteLine("\n---------------------------\n");

        E3();
        Console.WriteLine("\n---------------------------\n");

        E4();

        Console.WriteLine("\nFin del programa.");
        Console.ReadKey();
    }
    static void E1()
    {
        Console.WriteLine("Ejercicio 1: Vehículos");
        Console.Write("Tipo (1:Bici 2:Moto 3:Auto 4:Camión 5:Bus): ");

        if (int.TryParse(Console.ReadLine(), out int t))
        {
            switch (t)
            {
                case 1: Console.WriteLine("No motorizado"); break;
                case 2: Console.WriteLine("Ligero"); break;
                case 3: Console.WriteLine("Mediano"); break;
                case 4: Console.WriteLine("Pesado"); break;
                case 5: Console.WriteLine("Público"); break;
                default: Console.WriteLine("Fuera de rango"); break;
            }
        }
        else
            Console.WriteLine("Dato inválido");
    }

    static void E2()
    {
        Console.WriteLine("Ejercicio 2: Banco");

        Console.Write("Tipo tarjeta (1,2,3 u otro): ");
        int tt = int.Parse(Console.ReadLine());

        Console.Write("Límite actual: ");
        double la = double.Parse(Console.ReadLine());

        double pa = 0;

        if (tt == 1) pa = 0.25;
        else if (tt == 2) pa = 0.35;
        else if (tt == 3) pa = 0.40;
        else pa = 0.50;

        double nl = la + (la * pa);

        Console.WriteLine($"Nuevo límite: {nl:C}");
    }

    static void E3()
    {
        Console.WriteLine("Ejercicio 3: Evaluación");

        Console.Write("Puntuación (0.0, 0.4, 0.6+): ");

        if (double.TryParse(Console.ReadLine(), out double p))
        {
            string n = "";
            double d = 0;

            if (p == 0.0)
            {
                n = "Inaceptable";
                d = 2400 * p;
            }
            else if (p == 0.4)
            {
                n = "Aceptable";
                d = 2400 * p;
            }
            else if (p >= 0.6)
            {
                n = "Meritorio";
                d = 2400 * p;
            }
            else
            {
                Console.WriteLine("Puntuación inválida");
                return;
            }

            Console.WriteLine($"Nivel: {n}");
            Console.WriteLine($"Dinero: {d:C}");
        }
        else
            Console.WriteLine("Dato inválido");
    }

    static void E4()
    {
        Console.WriteLine("Ejercicio 4: Pizzería");

        Console.Write("¿Vegetariana? (s/n): ");
        string r = Console.ReadLine().ToLower();

        string tp = "";
        string ing = "";

        if (r == "s")
        {
            tp = "Vegetariana";
            Console.WriteLine("1.Pimiento  2.Tofu");
            Console.Write("Elija: ");
            string oi = Console.ReadLine();

            if (oi == "1") ing = "Pimiento";
            else if (oi == "2") ing = "Tofu";
            else
            {
                Console.WriteLine("Ingrediente inválido");
                return;
            }
        }
        else if (r == "n")
        {
            tp = "No vegetariana";
            Console.WriteLine("1.Peperoni  2.Jamón  3.Salmón");
            Console.Write("Elija: ");
            string oi = Console.ReadLine();

            if (oi == "1") ing = "Peperoni";
            else if (oi == "2") ing = "Jamón";
            else if (oi == "3") ing = "Salmón";
            else
            {
                Console.WriteLine("Ingrediente inválido");
                return;
            }
        }
        else
        {
            Console.WriteLine("Respuesta inválida");
            return;
        }

        Console.WriteLine($"\nPizza {tp} con:");
        Console.WriteLine("- Mozzarella");
        Console.WriteLine("- Tomate");
        Console.WriteLine($"- {ing}");
    }
}