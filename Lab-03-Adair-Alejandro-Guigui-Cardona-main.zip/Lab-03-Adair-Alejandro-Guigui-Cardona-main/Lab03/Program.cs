﻿using System;
namespace EejercicioLab3
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombreEstudiante;
            string nombreCurso;
            string mensajePersonalizado;
            Console.Write("Por favor, ingresa tu nombre: ");
            nombreEstudiante = Console.ReadLine();
            Console.Write("Ingresa el nombre del curso: ");
            nombreCurso = Console.ReadLine();
            Console.Write("Escribe un mensaje breve para mostrar: ");
            mensajePersonalizado = Console.ReadLine();
            Console.WriteLine("\n--- Resumen de Datos ---");
            Console.WriteLine("Estudiante: " + nombreEstudiante);
            Console.WriteLine("Curso: " + nombreCurso);
            Console.WriteLine("Mensaje: " + mensajePersonalizado);
            Console.WriteLine("\nPresiona cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}
