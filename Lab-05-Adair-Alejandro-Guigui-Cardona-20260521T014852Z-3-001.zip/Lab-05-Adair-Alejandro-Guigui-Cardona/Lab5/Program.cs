﻿using System;
class Program
{
    static void Main()
    {
        Ej1();
        Console.WriteLine("\n");
        Ej2();
        Console.WriteLine("\n");
        Ej3();
        Console.WriteLine("\n");
        Ej4();
    }

    static void Ej1()
    {
        int id, p, t, m;
        Console.WriteLine("sistema de control de acceso");
        Console.Write("id: ");
        id = int.Parse(Console.ReadLine());
        Console.Write("pin: ");
        p = int.Parse(Console.ReadLine());
        Console.Write("token: ");
        t = int.Parse(Console.ReadLine());
        Console.Write("modo seguro (1/0): ");
        m = int.Parse(Console.ReadLine());

        if (id == 2026) Console.WriteLine("usuario ok"); else Console.WriteLine("usuario no");
        if (p == 1234) Console.WriteLine("pin ok"); else Console.WriteLine("pin no");
        if (t == 777) Console.WriteLine("token ok"); else Console.WriteLine("token no");
        if (m == 1) Console.WriteLine("modo seguro on"); else Console.WriteLine("modo seguro off");

        bool a = id == 2026, b = p == 1234, c = t == 777;
        if (a && b && c) Console.WriteLine("acceso total"); else Console.WriteLine("acceso denegado");

        if (m == 1)
        {
            if (t >= 700) Console.WriteLine("regla extra ok");
            else Console.WriteLine("regla extra no");
        }
    }

    static void Ej2()
    {
        int p;
        Console.Write("pin: ");
        p = int.Parse(Console.ReadLine());

        if (p >= 1000 && p <= 9999) Console.WriteLine("4 digitos ok");
        else Console.WriteLine("pin invalido");

        if (p % 2 == 0) Console.WriteLine("par");
        else Console.WriteLine("impar");

        if (p % 5 == 0) Console.WriteLine("multiplo 5");
        else Console.WriteLine("no multiplo 5");

        bool a = p >= 1000 && p <= 9999, b = p % 2 == 0, c = p % 5 != 0;
        if (a && b && c) Console.WriteLine("aceptado");
        else Console.WriteLine("rechazado");
    }

    static void Ej3()
    {
        int c, e, t, d, s;
        Console.Write("codigo: ");
        c = int.Parse(Console.ReadLine());
        Console.Write("edad: ");
        e = int.Parse(Console.ReadLine());
        Console.Write("terminos (1/0): ");
        t = int.Parse(Console.ReadLine());
        Console.Write("2fa (1/0): ");
        d = int.Parse(Console.ReadLine());
        Console.Write("puntaje: ");
        s = int.Parse(Console.ReadLine());

        if (c == 2026) Console.WriteLine("codigo ok"); else Console.WriteLine("codigo no");
        if (e >= 18) Console.WriteLine("edad ok"); else Console.WriteLine("edad no");
        if (t == 1) Console.WriteLine("terminos ok"); else Console.WriteLine("terminos no");
        if (d == 1) Console.WriteLine("2fa ok"); else Console.WriteLine("2fa no");
        if (s >= 70) Console.WriteLine("puntaje ok"); else Console.WriteLine("puntaje no");

        bool a = c == 2026, b = e >= 18, f = t == 1, g = d == 1, h = s >= 70;
        if (a && b && f && g && h) Console.WriteLine("cuenta activada");
        else Console.WriteLine("cuenta no activada");
    }

    static void Ej4()
    {
        int n, m, s, i, c;
        Console.Write("nota: ");
        n = int.Parse(Console.ReadLine());
        Console.Write("tarde: ");
        m = int.Parse(Console.ReadLine());
        Console.Write("solvencia (1/0): ");
        s = int.Parse(Console.ReadLine());
        Console.Write("id fisica (1/0): ");
        i = int.Parse(Console.ReadLine());
        Console.Write("calculadora (1/0): ");
        c = int.Parse(Console.ReadLine());

        if (n >= 61) Console.WriteLine("academico ok"); else Console.WriteLine("academico no");
        if (m <= 10) Console.WriteLine("hora ok"); else Console.WriteLine("fuera de tiempo");
        if (s == 1) Console.WriteLine("solvencia ok"); else Console.WriteLine("sin solvencia");
        if (i == 1) Console.WriteLine("id ok"); else Console.WriteLine("sin id");
        if (c == 1) Console.WriteLine("calculadora ok"); else Console.WriteLine("sin calculadora");

        bool a = n >= 61, b = m <= 10, d = s == 1, e = i == 1;
        if (a && b && d && e) Console.WriteLine("acceso concedido");
        else Console.WriteLine("acceso denegado");

        if (m > 0 && m <= 10) Console.WriteLine("advertencia: llego tarde");
    }

    static void Bonus()
    {
        string n;
        int v, gp, gm, i, s;
        Console.WriteLine("algoritmo del destino romantico");
        Console.Write("nombre: ");
        n = Console.ReadLine();
        Console.Write("valentia (0-100): ");
        v = int.Parse(Console.ReadLine());
        Console.Write("le gusta programacion (1/0): ");
        gp = int.Parse(Console.ReadLine());
        Console.Write("le gustan memes (1/0): ");
        gm = int.Parse(Console.ReadLine());
        Console.Write("interes (0-100): ");
        i = int.Parse(Console.ReadLine());
        Console.Write("soltera/o (1/0): ");
        s = int.Parse(Console.ReadLine());
        if (i >= 70) Console.WriteLine("interes alto");
        else Console.WriteLine("interes bajo");
        if (v >= 70) Console.WriteLine("valentia alta");
        else Console.WriteLine("valentia baja");
        if (s == 1) Console.WriteLine("estado favorable");
        else Console.WriteLine("estado comprometido");
        if (gp == 1 && gm == 1) Console.WriteLine("compatibilidad geek");
        else Console.WriteLine("compatibilidad baja");
        bool a = i >= 70, b = s == 1, c = gp == 1, d = gm == 1, e = v >= 70;
        if (a && b && c && d && e)
            Console.WriteLine("declaracion aprobada");
        else if (a && b && c && d && !e)
            Console.WriteLine("no le tenga miedo al exito");
        else
            Console.WriteLine(n + ", no te ama..por ahora");
        Console.WriteLine("casos de prueba:");
        Console.WriteLine("1: valentina 85 1 1 80 1 -> declaracion aprobada");
        Console.WriteLine("2: carlos 45 1 1 75 1 -> no le tenga miedo al exito");
        Console.WriteLine("3: maria 90 1 1 45 1 -> maria, no te ama..por ahora");
        Console.WriteLine("4: roberto 95 1 1 85 0 -> roberto, no te ama..por ahora");
        Console.WriteLine("5: laura 80 0 0 90 1 -> laura, no te ama..por ahora");
    }
}