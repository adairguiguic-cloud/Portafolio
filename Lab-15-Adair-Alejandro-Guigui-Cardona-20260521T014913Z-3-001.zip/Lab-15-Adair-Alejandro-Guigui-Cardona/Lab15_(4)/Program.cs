﻿using System;

class Program
{
    static void Main()
    {
        double baseRectangulo = 0;
        double alturaRectangulo = 0;
        bool valido = false;

        // Validación de la base
        while (!valido)
        {
            Console.WriteLine("Ingrese la base del rectángulo:");

            // Error corregido: Se usa TryParse para evitar errores si el usuario escribe texto.
            if (double.TryParse(Console.ReadLine(), out baseRectangulo))
            {
                // Error corregido: La base no puede ser menor o igual a cero.
                if (baseRectangulo > 0)
                {
                    valido = true;
                }
                else
                {
                    Console.WriteLine("La base debe ser mayor que cero.");
                }
            }
            else
            {
                Console.WriteLine("Entrada inválida. Ingrese un número.");
            }
        }

        valido = false;
        while (!valido)
        {
            Console.WriteLine("Ingrese la altura del rectángulo:");

            // Se usa TryParse para evitar errores de ejecución
            if (double.TryParse(Console.ReadLine(), out alturaRectangulo))
            {
                // La altura debe ser mayor que cero
                if (alturaRectangulo > 0)
                {
                    valido = true;
                }
                else
                {
                    Console.WriteLine("La altura debe ser mayor que cero.");
                }
            }
            else
            {
                Console.WriteLine("Entrada inválida. Ingrese un número.");
            }
        }

        // Cálculo del área
        double area = CalcularArea(baseRectangulo, alturaRectangulo);

        // Mensajes de comprobación
        Console.WriteLine("Base ingresada: " + baseRectangulo);
        Console.WriteLine("Altura ingresada: " + alturaRectangulo);
        Console.WriteLine("El área es: " + area);

        // Error corregido:Se usa >= 100 si considera 100 como área grande.
        if (area >= 100)
        {
            Console.WriteLine("El área es grande");
        }
        else
        {
            Console.WriteLine("El área es pequeña");
        }
    }

    static double CalcularArea(double baseRectangulo, double alturaRectangulo)
    {
        // Error corregido: El área correcta de un rectángulo es base × altura.
        double resultado = baseRectangulo * alturaRectangulo;

        return resultado;
    }
}