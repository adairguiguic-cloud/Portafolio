﻿using System; // Error corregido: faltaba el punto y coma (;)

class Program
{
    static void Main()
    {
        string nombre; // Error corregido: faltaba el punto y coma (;)
        int edad;

        Console.WriteLine("Ingrese su nombre:");
        nombre = Console.ReadLine();

        Console.WriteLine("Ingrese su edad:");
        edad = int.Parse(Console.ReadLine());
        // Error corregido: faltaba el punto y coma (;)

        Console.WriteLine("Hola " + nombre);
        Console.WriteLine("Tienes " + edad + " años");

        if (edad >= 18)
        {
            Console.WriteLine("Eres mayor de edad");
        } // Error corregido: faltaba cerrar la llave del if

        else
        {
            Console.WriteLine("Eres menor de edad");
        }
    }
}