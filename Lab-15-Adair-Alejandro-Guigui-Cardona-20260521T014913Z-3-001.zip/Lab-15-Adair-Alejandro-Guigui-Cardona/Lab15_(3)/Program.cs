﻿using System;

class Program
{
    static void Main()
    {
        int[] numeros = new int[5];
        int suma = 0;
        int numero;
        bool valido;

        // Error corregido: Se usa i < 5 para recorrer solo posiciones válidas.
        for (int i = 0; i < 5; i++)
        {
            valido = false;

            while (!valido)
            {
                Console.WriteLine("Ingrese un número:");

                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    numeros[i] = numero;
                    valido = true;
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Intente de nuevo.");
                }
            }
        }

        // Error corregido: Debía recorrer únicamente las posiciones válidas del arreglo.
        for (int i = 0; i < 5; i++)
        {
            suma = suma + numeros[i];
        }

        Console.WriteLine("La suma total es: " + suma);
    }
}