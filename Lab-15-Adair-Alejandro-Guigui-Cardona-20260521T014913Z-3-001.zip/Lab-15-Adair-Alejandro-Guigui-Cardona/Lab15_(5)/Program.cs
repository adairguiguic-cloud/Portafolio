﻿using System;

class Program
{
    static void Main()
    {
        int[] edades = new int[5];
        int suma = 0;
        int mayores = 0;
        double promedio;

        int edad;
        bool valido;

        // Análisis de la solución generada por IA:
        // Error 1:
        // El ciclo comenzaba en 1 y terminaba en 5.
        // Esto provocaba un error porque el arreglo solo
        // tiene posiciones válidas de 0 a 4.

        // Error 2:
        // La condición edades[i] > 18 dejaba fuera a las
        // personas de exactamente 18 años.

        // Error 3:
        // El promedio se calculaba usando división entera.
        // Aunque promedio es double, suma y 5 son enteros,
        // lo que podía eliminar decimales.

        // Limitación encontrada:
        // La solución generada por IA no incluía validaciones
        // para texto ni para edades negativas.

        // Importancia de la validación humana:
        // La IA puede generar código con errores lógicos o de ejecución.
        // Por eso es importante que una persona revise,
        // pruebe y valide los resultados antes de utilizar el programa.

        // Ciclo corregido:
        // Ahora utiliza posiciones válidas del arreglo (0 a 4)
        for (int i = 0; i < 5; i++)
        {
            valido = false;

            while (!valido)
            {
                Console.WriteLine("Ingrese la edad de la persona " + (i + 1) + ":");

                // Validación para evitar errores si el usuario escribe texto
                if (int.TryParse(Console.ReadLine(), out edad))
                {
                    // Validación para evitar edades negativas
                    if (edad >= 0)
                    {
                        edades[i] = edad;
                        suma = suma + edades[i];

                        // Condición corregida: Ahora 18 también cuenta como mayor de edad
                        if (edades[i] >= 18)
                        {
                            mayores++;
                        }

                        valido = true;
                    }
                    else
                    {
                        Console.WriteLine("La edad no puede ser negativa.");
                    }
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Ingrese un número entero.");
                }
            }
        }

        // Corrección del promedio: Se usa 5.0 para forzar división decimal
        promedio = suma / 5.0;

        Console.WriteLine("El promedio de edades es: " + promedio);
        Console.WriteLine("Cantidad de mayores de edad: " + mayores);
    }
}

// ¿Por qué una solución generada por Inteligencia Artificial debe ser revisada,
// probada y validada por una persona antes de considerarse correcta?

// Aunque la Inteligencia Artificial puede ayudar mucho al programar,
// no significa que siempre entregue soluciones perfectas.
// En este ejercicio, por ejemplo, el código tenía errores en arreglos,
// condiciones y cálculos que podían pasar desapercibidos.
// La IA genera respuestas basadas en patrones, pero no piensa ni analiza
// como una persona que prueba el programa paso a paso.
// Por eso es importante revisar el código manualmente, hacer pruebas
// y comprobar que los resultados realmente sean correctos antes de usarlo.