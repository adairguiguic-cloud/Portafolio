﻿using System;
class Persona
{
    public string nombre;
    public int edad;
    public double altura;
    public bool estudiante;
}
class Vehiculo
{
    public string marca;
    public string modelo;
    public int anio;
    public string color;
    public string placa;
}
class Producto
{
    public string codigo;
    public string nombre;
    public double precio;
    public int stock;
    public bool disponible;
}
class Mascota
{
    public string nombre;
    public string especie;
    public int edad;
    public double peso;
    public bool vacunado;
}
class Program
{
    static void Main()
    {
        Persona persona = new Persona();
        persona.nombre = "Juan Pérez";
        persona.edad = 25;
        persona.altura = 1.75;
        persona.estudiante = true;

        Console.WriteLine("Persona");
        Console.WriteLine(persona.nombre);
        Console.WriteLine(persona.edad);
        Console.WriteLine(persona.altura);
        Console.WriteLine(persona.estudiante);
        Console.WriteLine();

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.marca = "Toyota";
        vehiculo.modelo = "Corolla";
        vehiculo.anio = 2022;
        vehiculo.color = "Rojo";
        vehiculo.placa = "ABC123";

        Console.WriteLine("Vehiculo");
        Console.WriteLine(vehiculo.marca);
        Console.WriteLine(vehiculo.modelo);
        Console.WriteLine(vehiculo.anio);
        Console.WriteLine(vehiculo.color);
        Console.WriteLine(vehiculo.placa);
        Console.WriteLine();

        Producto producto1 = new Producto();
        producto1.codigo = "P001";
        producto1.nombre = "Laptop";
        producto1.precio = 2500.99;
        producto1.stock = 15;
        producto1.disponible = true;

        Producto producto2 = new Producto();
        producto2.codigo = "P002";
        producto2.nombre = "Mouse";
        producto2.precio = 25.50;
        producto2.stock = 50;
        producto2.disponible = true;

        Console.WriteLine("Producto 1");
        Console.WriteLine(producto1.codigo);
        Console.WriteLine(producto1.nombre);
        Console.WriteLine(producto1.precio);
        Console.WriteLine(producto1.stock);
        Console.WriteLine(producto1.disponible);

        Console.WriteLine("Producto 2");
        Console.WriteLine(producto2.codigo);
        Console.WriteLine(producto2.nombre);
        Console.WriteLine(producto2.precio);
        Console.WriteLine(producto2.stock);
        Console.WriteLine(producto2.disponible);
        Console.WriteLine();

        Mascota mascota = new Mascota();
        mascota.nombre = "Firulais";
        mascota.especie = "Perro";
        mascota.edad = 3;
        mascota.peso = 15.5;
        mascota.vacunado = true;

        Console.WriteLine("Mascota");
        Console.WriteLine(mascota.nombre);
        Console.WriteLine(mascota.especie);
        Console.WriteLine(mascota.edad);
        Console.WriteLine(mascota.peso);
        Console.WriteLine(mascota.vacunado);

        Console.ReadKey();
    }
}