﻿using System;

class Program
{
    static void Ejercicio1()
    {
        Console.Clear();
        Console.WriteLine("=== EJERCICIO 1 ===");
        Console.Write("Nombre: ");
        string n = Console.ReadLine();

        Saludo(n);
        Info();
        Console.WriteLine("\nEnter para continuar...");
        Console.ReadLine();
    }

    static void Saludo(string n)
    {
        Console.WriteLine($"Hola {n}");
    }

    static void Info()
    {
        Console.WriteLine("Programación I");
    }

    static void Ejercicio2()
    {
        Console.Clear();
        Console.WriteLine("=== EJERCICIO 2 ===");

        Console.Write("Lado: ");
        double l = double.Parse(Console.ReadLine());
        Cuadrado(l);

        Console.Write("Base: ");
        double b = double.Parse(Console.ReadLine());
        Console.Write("Altura: ");
        double h = double.Parse(Console.ReadLine());
        Rectangulo(b, h);

        Console.Write("Base: ");
        double bt = double.Parse(Console.ReadLine());
        Console.Write("Altura: ");
        double ht = double.Parse(Console.ReadLine());
        Triangulo(bt, ht);

        Console.WriteLine("\nEnter para continuar...");
        Console.ReadLine();
    }

    static void Cuadrado(double l)
    {
        Console.WriteLine($"Área: {l * l:F2}");
    }

    static void Rectangulo(double b, double h)
    {
        Console.WriteLine($"Área: {b * h:F2}");
    }

    static void Triangulo(double b, double h)
    {
        Console.WriteLine($"Área: {(b * h) / 2:F2}");
    }

    static void Ejercicio3()
    {
        int op, n;

        do
        {
            Console.Clear();
            Console.WriteLine("=== EJERCICIO 3 ===");
            Console.WriteLine("1. Cuadrado");
            Console.WriteLine("2. Triángulo");
            Console.WriteLine("3. Línea");
            Console.WriteLine("4. Salir");
            Console.Write("Opción: ");
            op = int.Parse(Console.ReadLine());

            if (op >= 1 && op <= 3)
            {
                Console.Write("N: ");
                n = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1: FCuadrado(n); break;
                    case 2: FTriangulo(n); break;
                    case 3: FLinea(n); break;
                }
                Console.WriteLine("\nEnter...");
                Console.ReadLine();
            }
        } while (op != 4);
    }

    static void FCuadrado(int n)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
                Console.Write("*");
            Console.WriteLine();
        }
    }

    static void FTriangulo(int n)
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= i; j++)
                Console.Write("*");
            Console.WriteLine();
        }
    }

    static void FLinea(int n)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j <= i; j++)
                Console.Write("*");
            Console.WriteLine();
        }
        for (int i = n - 2; i >= 0; i--)
        {
            for (int j = 0; j <= i; j++)
                Console.Write("*");
            Console.WriteLine();
        }
    }

    static void Ejercicio4()
    {
        Console.Clear();
        double[] n = new double[5];
        int a = 0, r = 0;
        double s = 0;

        Console.WriteLine("=== EJERCICIO 4 ===");
        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Nota {i + 1}: ");
            n[i] = double.Parse(Console.ReadLine());
            string res = Eval(n[i]);
            Console.WriteLine(res);

            s += n[i];
            if (n[i] >= 61) a++;
            else r++;
        }

        Resumen(s / 5, a, r);
        Console.WriteLine("\nEnter...");
        Console.ReadLine();
    }

    static string Eval(double n)
    {
        return (n >= 61) ? "APROBADO" : "REPROBADO";
    }

    static void Resumen(double p, int a, int r)
    {
        Console.WriteLine($"Promedio: {p:F2}");
        Console.WriteLine($"Aprobados: {a}");
        Console.WriteLine($"Reprobados: {r}");
    }

    static void Ejercicio5()
    {
        Console.Clear();
        Console.Write("Num1: ");
        int a = int.Parse(Console.ReadLine());
        Console.Write("Num2: ");
        int b = int.Parse(Console.ReadLine());

        Console.WriteLine($"Antes: {a}, {b}");

        Swap(ref a, ref b);

        Console.WriteLine($"Después: {a}, {b}");
        Console.WriteLine("\nEnter...");
        Console.ReadLine();
    }

    static void Swap(ref int x, ref int y)
    {
        int t = x;
        x = y;
        y = t;
    }

    static void Main()
    {
        int op;

        do
        {
            Console.Clear();
            Console.WriteLine("MENU");
            Console.WriteLine("1. Ej1");
            Console.WriteLine("2. Ej2");
            Console.WriteLine("3. Ej3");
            Console.WriteLine("4. Ej4");
            Console.WriteLine("5. Ej5");
            Console.WriteLine("0. Salir");
            Console.Write("Opción: ");
            op = int.Parse(Console.ReadLine());

            switch (op)
            {
                case 1: Ejercicio1(); break;
                case 2: Ejercicio2(); break;
                case 3: Ejercicio3(); break;
                case 4: Ejercicio4(); break;
                case 5: Ejercicio5(); break;
                case 0: Console.WriteLine("Fin"); break;
                default: Console.WriteLine("Error"); Console.ReadLine(); break;
            }
        } while (op != 0);
    }
}